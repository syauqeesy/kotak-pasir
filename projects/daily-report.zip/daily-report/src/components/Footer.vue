<template>
  <footer class="Footer mt-5 bg-light">
    <p class="text-center">Created by Ahmad Syauqi</p>
  </footer>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style scoped>
  footer {
    height: 100px;
    line-height: 100px;
  }
</style>
