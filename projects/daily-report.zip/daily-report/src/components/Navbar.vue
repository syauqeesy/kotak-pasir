<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-light mb-5">
    <div class="container">
      <router-link class="navbar-brand" to="/">DailyReport</router-link>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-content" aria-controls="navbar-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbar-content">
        <div class="navbar-nav ms-auto">
          <router-link class="nav-link" to="/create">create report</router-link>
          <router-link class="nav-link" to="/profile">account</router-link>
          <a @click="logout" class="nav-link text-danger logout-button">logout</a>
        </div>
      </div>
    </div>
  </nav>
</template>

<script>
export default {
  name: 'Navbar',
  methods: {
    logout () {
      localStorage.removeItem('token')
      localStorage.removeItem('roleId')
      localStorage.removeItem('userId')
      this.$router.push({ path: '/login' })
    }
  }
}
</script>

<style scoped>
  nav div.container {
    width: 560px;
  }

  a.logout-button {
    cursor: pointer;
  }
</style>
