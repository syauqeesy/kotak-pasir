import { createStore } from 'vuex'
import axios from 'axios'

const request = (url, method, data, callback = () => console.log('Request running')) => {
  return new Promise((resolve, reject) => {
    const errorData = {
      status: 'Failed',
      message: 'Request method not supported!'
    }

    switch (method) {
      case 'get':
        axios.get(process.env.VUE_APP_BASE_URL + url, {
          headers: {
            authorization: `Bearer ${localStorage.getItem('token') || ''}`
          }
        })
          .then(response => {
            callback(response.data)
            resolve(response.data)
          })
          .catch(error => {
            reject(error.response.data)
          })
        break
      case 'post':
        axios.post(process.env.VUE_APP_BASE_URL + url, data, {
          headers: {
            authorization: `Bearer ${localStorage.getItem('token') || ''}`
          }
        })
          .then(response => {
            callback(response.data)
            resolve(response.data)
          })
          .catch(error => {
            reject(error.response.data)
          })
        break
      case 'patch':
        axios.patch(process.env.VUE_APP_BASE_URL + url, data, {
          headers: {
            authorization: `Bearer ${localStorage.getItem('token') || ''}`
          }
        })
          .then(response => {
            callback(response.data)
            resolve(response.data)
          })
          .catch(error => {
            reject(error.response.data)
          })
        break
      default:
        reject(errorData)
        break
    }
  })
}

export default createStore({
  state: {
    user: {},
    reports: []
  },
  mutations: {
    setUserData (state, payload) {
      state.user = payload
    },
    setReportsData (state, payload) {
      state.reports = payload
    }
  },
  actions: {
    requestRegister (_, payload) {
      return request('/api/user/register', 'post', payload)
    },
    requestLogin (_, payload) {
      return request('/api/user/login', 'post', payload)
    },
    requestUserData ({ commit }, payload) {
      return request(`/api/user/${payload}`, 'get', {}, (data) => {
        commit('setUserData', data.user)
      })
    },
    requestChangeProfile (_, payload) {
      return request(`/api/user/${payload.get('userId')}`, 'patch', payload, (_) => {
        //
      })
    },
    requestChangePassword (_, payload) {
      return request(`/api/user/changepassword/${payload.userId}`, 'patch', payload, (_) => {
        //
      })
    },
    requestCreateReport (_, payload) {
      return request('/api/report/create', 'post', payload)
    },
    requestGetAllReport ({ commit }, payload) {
      return request(`/api/report/all?filter=${payload.filter || ''}`, 'get', {}, (data) => {
        console.log(data.reports)
        commit('setReportsData', data.reports)
      })
    },
    requestGetMyReport ({ commit }, payload) {
      return request(`/api/report/my?filter=${payload.filter || ''}&userId=${localStorage.getItem('userId')}`, 'get', {}, (data) => {
        console.log(data.reports)
        commit('setReportsData', data.reports)
      })
    }
  },
  getters: {
    user (state) {
      return state.user
    },
    reports (state) {
      return state.reports
    }
  }
})
