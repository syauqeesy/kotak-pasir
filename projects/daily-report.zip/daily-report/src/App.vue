<template>
  <div class="App">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
  div.App {
    color: #707070;
  }

  div.container {
    width: 560px;
  }
</style>
