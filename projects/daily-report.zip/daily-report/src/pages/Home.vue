<template>
  <Navbar />
  <div class="Home">
    <div class="container">
      <h2 class="mb-5" v-if="roleId === '2'">My reports</h2>
      <h2 class="mb-5" v-if="roleId === '1'">All reports</h2>
      <div class="btn-group mb-3" role="group" aria-label="Basic example">
        <router-link to="/?filter=" class="btn btn-outline-secondary">all</router-link>
        <router-link to="/?filter=today" class="btn btn-outline-secondary">today</router-link>
        <router-link to="/?filter=week" class="btn btn-outline-secondary">this week</router-link>
        <router-link to="/?filter=month" class="btn btn-outline-secondary">this month</router-link>
      </div>

      <div class="card mb-3" v-for="report in reports" v-bind:key="report.id">
        <div class="card-body">
          <p class="fw-bold fs-5" v-if="roleId === '1'">{{ report.full_name }}</p>
          <p>{{ report.body }}</p>
          <p class="small text-muted">{{ moment(new Date(report.createdAt)).format('YYYY-MM-DD') }}</p>
        </div>
      </div>
    </div>
  </div>
  <Footer />
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import moment from 'moment'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'

export default {
  name: 'Home',
  data () {
    return {
      roleId: '',
      moment
    }
  },
  components: {
    Footer,
    Navbar
  },
  computed: {
    ...mapGetters(['reports'])
  },
  methods: {
    ...mapActions(['requestGetAllReport', 'requestGetMyReport'])
  },
  async mounted () {
    try {
      this.roleId = localStorage.getItem('roleId')
      if (localStorage.getItem('roleId') === '1') {
        await this.requestGetAllReport({ filter: this.$route.query.filter || '' })
      } else {
        await this.requestGetMyReport({ userId: localStorage.getItem('userId'), filter: this.$route.query.filter || '' })
      }
    } catch (error) {
      this.$swal(error.message)
    }
  },
  watch: {
    async $route () {
      try {
        if (localStorage.getItem('roleId') === '1') {
          await this.requestGetAllReport({ filter: this.$route.query.filter || '' })
        } else {
          await this.requestGetMyReport({ userId: localStorage.getItem('userId'), filter: this.$route.query.filter || '' })
        }
      } catch (error) {
        // this.$swal(error.message)
      }
    }
  }
}
</script>

<style scoped>
  div.Home {
    min-height: 450px;
  }
</style>
