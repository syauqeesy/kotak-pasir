<template>
  <div class="Login mt-5">
    <div class="container">
      <h2>Login</h2>
      <form class="mt-5 mb-3" @submit.prevent="login">
        <div class="mb-3">
          <label for="nik" class="form-label">NIK</label>
          <input type="text" class="form-control" id="nik" v-model="nik" placeholder="327xxx" autocomplete="off">
        </div>
        <div class="mb-5">
          <label for="password" class="form-label">Password</label>
          <input type="password" class="form-control" v-model="password" id="password">
        </div>
        <div class="d-grid">
          <button type="submit" class="btn btn-outline-secondary">login</button>
        </div>
      </form>
      <router-link class="small" to="/register">Doesn't have an account? Let's register</router-link>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
  name: 'Login',
  data () {
    return {
      nik: '',
      password: ''
    }
  },
  methods: {
    ...mapActions(['requestLogin']),
    async login () {
      try {
        const loginData = {
          nik: this.nik,
          password: this.password
        }

        const result = await this.requestLogin(loginData)
        localStorage.setItem('token', result.token)
        localStorage.setItem('roleId', result.roleId)
        localStorage.setItem('userId', result.userId)
        this.$swal(result.message)
        this.$router.push({ path: '/' })
      } catch (error) {
        this.$swal(error.message)
      }
    }
  }
}
</script>

<style scoped>

</style>
