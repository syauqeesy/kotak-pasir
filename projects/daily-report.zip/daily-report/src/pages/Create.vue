<template>
  <Navbar />
  <div class="Create">
    <div class="container">
      <h2 class="mb-5">Create new report</h2>
      <form @submit.prevent="createReport">
        <div class="mb-3">
          <label for="report" class="form-label">Report</label>
          <textarea class="form-control" v-model="body" id="report" rows="7" autocomplete="off"></textarea>
        </div>
        <div class="d-grid">
          <button type="submit" class="btn btn-outline-secondary">send</button>
        </div>
      </form>
    </div>
  </div>
  <Footer />
</template>

<script>
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import { mapActions } from 'vuex'

export default {
  name: 'Create',
  data () {
    return {
      body: '',
      userId: ''
    }
  },
  components: {
    Navbar,
    Footer
  },
  methods: {
    ...mapActions(['requestCreateReport']),
    async createReport () {
      try {
        const createReportData = {
          userId: localStorage.getItem('userId'),
          body: this.body
        }

        const result = await this.requestCreateReport(createReportData)
        this.$swal(result.message)
        this.$router.push({ path: '/' })
      } catch (error) {
        this.$swal(error.message)
      }
    }
  }
}
</script>

<style scoped>
  div.Create {
    min-height: 450px;
  }
</style>
