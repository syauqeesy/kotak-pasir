<template>
  <Navbar />
  <div class="Profile">
    <div class="container">
      <h2 class="mb-5">My profile</h2>
      <img :src="profilePicture" class="mb-5 rounded-circle border border-secondary mx-auto d-block" width="100" height="100" alt="...">
      <form class="mb-5" @submit.prevent="changeProfile">
        <div class="mb-3">
          <label for="profilePicture" class="form-label">Change profile picture</label>
          <input class="form-control" type="file" ref="profilePicture" id="profilePicture">
        </div>
        <div class="mb-3">
          <label for="nik" class="form-label">NIK</label>
          <input type="text" disabled class="form-control" id="nik" v-model="nik" placeholder="Your name" autocomplete="off">
        </div>
        <div class="mb-5">
          <label for="fullName" class="form-label">Full name</label>
          <input type="text" class="form-control" id="fullName" v-model="fullName" placeholder="Your name" autocomplete="off">
        </div>
        <div class="d-grid">
          <button type="submit" class="btn btn-outline-secondary">save changes</button>
        </div>
      </form>

      <h2 class="mb-4">Change password</h2>
      <form @submit.prevent="changePassword">
        <div class="mb-3">
          <label for="oldPassword" class="form-label">Old password</label>
          <input type="password" class="form-control" v-model="oldPassword" id="oldPassword" placeholder="Old password">
        </div>
        <div class="mb-5">
          <label for="newPassword" class="form-label">New password</label>
          <input type="password" class="form-control" v-model="newPassword" id="newPassword" placeholder="New password">
        </div>
        <div class="d-grid">
          <button type="submit" class="btn btn-outline-secondary">Confirm</button>
        </div>
      </form>
    </div>
  </div>
  <Footer />
</template>

<script>
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import { mapActions, mapGetters } from 'vuex'

export default {
  name: 'Profile',
  data () {
    return {
      fullName: '',
      profilePicture: '',
      nik: '',
      oldPassword: '',
      newPassword: ''
    }
  },
  computed: {
    ...mapGetters(['user'])
  },
  components: {
    Navbar,
    Footer
  },
  methods: {
    ...mapActions(['requestUserData', 'requestChangeProfile', 'requestChangePassword']),
    async changeProfile () {
      try {
        const formData = new FormData()
        const file = this.$refs.profilePicture.files[0]
        if (file) {
          formData.append('profilePicture', file, file.name)
        }
        formData.append('fullName', this.fullName)
        formData.append('userId', localStorage.getItem('userId'))

        const result = await this.requestChangeProfile(formData)

        await this.requestUserData(localStorage.getItem('userId'))

        this.fullName = this.user.full_name
        this.profilePicture = process.env.VUE_APP_BASE_URL + '/images/' + this.user.profile_picture

        this.$swal(result.message)
      } catch (error) {
        this.$swal(error.message)
      }
    },
    async changePassword () {
      try {
        const changePasswordData = {
          oldPassword: this.oldPassword,
          newPassword: this.newPassword,
          userId: localStorage.getItem('userId')
        }

        const result = await this.requestChangePassword(changePasswordData)
        this.$swal(result.message)
        localStorage.removeItem('token')
        localStorage.removeItem('roleId')
        localStorage.removeItem('userId')
        this.$router.push({ path: '/login' })
      } catch (error) {
        this.$swal(error.message)
      }
    }
  },
  async mounted () {
    try {
      await this.requestUserData(localStorage.getItem('userId'))
      this.fullName = this.user.full_name
      this.nik = this.user.nik
      this.profilePicture = process.env.VUE_APP_BASE_URL + '/images/' + this.user.profile_picture
    } catch (error) {
      this.$swal(error.message)
    }
  }
}
</script>

<style scoped>

</style>
