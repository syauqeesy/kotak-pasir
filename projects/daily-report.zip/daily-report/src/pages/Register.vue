<template>
  <div class="Register mt-5">
    <div class="container">
      <h2>Register</h2>
      <form class="mt-5 mb-3" @submit.prevent="register">
        <div class="mb-3">
          <label for="nik" class="form-label">NIK</label>
          <input type="text" class="form-control" id="nik" placeholder="327xxx" v-model="nik" autocomplete="off">
        </div>
        <div class="mb-3">
          <label for="fullName" class="form-label">Full name</label>
          <input type="text" class="form-control" id="fullName" placeholder="Your name" v-model="fullName" autocomplete="off">
        </div>
        <div class="mb-2">
          <label for="password" class="form-label">Password</label>
          <input type="password" class="form-control" id="password" v-model="password">
        </div>
        <div class="row mb-5">
          <div class="col-3">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="roleId" v-model="roleId" value="1" id="manajer">
              <label class="form-check-label" for="manajer">
                Manajer
              </label>
            </div>
          </div>
          <div class="col-3">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="roleId" v-model="roleId" value="2" id="pegawai">
              <label class="form-check-label" for="pegawai">
                Pegawai
              </label>
            </div>
          </div>
        </div>
        <div class="d-grid">
          <button type="submit" class="btn btn-outline-secondary">register</button>
        </div>
      </form>
        <router-link class="small" to="/login">Already have an account? Let's login</router-link>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
  name: 'Register',
  data () {
    return {
      nik: '',
      fullName: '',
      password: '',
      roleId: ''
    }
  },
  methods: {
    ...mapActions(['requestRegister']),
    async register () {
      try {
        const registerData = {
          nik: this.nik,
          fullName: this.fullName,
          password: this.password,
          roleId: this.roleId
        }

        const result = await this.requestRegister(registerData)
        this.$swal(result.message)
        this.$router.push({ path: '/login' })
      } catch (error) {
        this.$swal(error.message)
      }
    }
  }
}
</script>

<style scoped>

</style>
