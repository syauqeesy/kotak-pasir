# Daily Report Front End
Make sure you already checked the Back End repository [here](https://github.com/syauqeesy/daily-report-api)

## About
This repo is for JNE technical test.

## Installation
1. Clone this repository https://github.com/syauqeesy/daily-report.
2. Install dependencies by running `npm install` command.
3. Copy `env` file to `.env`.
4. Config `VUE_APP_BASE_URL=http://yourdomain.com`.
5. Run the application with `npm run serve` command.
