package main

import (
	"github.com/syauqeesy/social-media/cmd"
)

func main() {
	cmd.Execute()
}
