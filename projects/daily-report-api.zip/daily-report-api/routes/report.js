const path = require('path')
const router = require('express').Router()
const reportController = require(path.join(__dirname, '../', 'controllers', 'report.js'))

const verifyToken = require(path.join(__dirname, '../', 'middlewares', 'verifyToken.js'))
const verifyRole = require(path.join(__dirname, '../', 'middlewares', 'verifyRole.js'))

module.exports = router
  .post('/create', verifyToken, reportController.createReport)
  .get('/my', verifyToken, reportController.myReport)
  .get('/all', [verifyToken, verifyRole], reportController.allReport)
