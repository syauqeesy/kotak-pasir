const path = require('path')
const router = require('express').Router()
const userController = require(path.join(__dirname, '../', 'controllers', 'user.js'))

const verifyToken = require(path.join(__dirname, '../', 'middlewares', 'verifyToken.js'))
const upload = require(path.join(__dirname, '../', 'middlewares', 'upload.js'))

module.exports = router
  .post('/register', userController.register)
  .post('/login', userController.login)
  .get('/:id', verifyToken, userController.getById)
  .patch('/changepassword/:id', verifyToken, userController.changePassword)
  .patch('/:id', [verifyToken, upload.single('profilePicture')], userController.updateProfile)
