require('dotenv').config()
const path = require('path')
const express = require('express')
const cors = require('cors')

const app = express()
const port = process.env.PORT || 5000
const { sequelize } = require(path.join(__dirname, 'models'))

const user = require(path.join(__dirname, 'routes', 'user.js'))
const report = require(path.join(__dirname, 'routes', 'report.js'))

app.use(cors())
app.use(express.urlencoded({ extended: false }))
app.use(express.json())
app.use('/images', express.static(path.join(__dirname, 'images')))

app.use('/api/user', user)
app.use('/api/report', report)

app.listen(port, async () => {
  console.log(`Server running on PORT: ${port}`)
  try {
    await sequelize.authenticate()
    console.log('database connected')
  } catch (error) {
    console.log(error)
  }
})
