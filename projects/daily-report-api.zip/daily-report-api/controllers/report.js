const path = require('path')
const { QueryTypes } = require('sequelize')
const { Report, sequelize } = require(path.join(__dirname, '../', 'models'))
const moment = require('moment')

module.exports = {
  async createReport (req, res) {
    try {
      // Insert new report
      await Report.create({ user_id: req.body.userId, body: req.body.body })

      // Send response
      return res.status(201).send({
        statusCode: 201,
        status: 'Success',
        message: 'Report created'
      })
    } catch (error) {
      console.log(error)
      return res.status(500).send({
        statusCode: 500,
        status: 'Failed',
        message: 'Internal server error'
      })
    }
  },

  async myReport (req, res) {
    try {
      // Filter
      let filter = ''
      switch (req.query.filter) {
        case 'today':
          filter = `WHERE DATE(reports.createdAt) = '${moment(Date.now()).format('YYYY-MM-DD')}'`
          break
        case 'week':
          filter = `WHERE DATE(reports.createdAt) BETWEEN '${moment(Date.now()).subtract(7, 'days').format('YYYY-MM-DD')}' AND '${moment(Date.now()).format('YYYY-MM-DD')}'`
          break
        case 'month':
          filter = `WHERE DATE(reports.createdAt) BETWEEN '${moment(Date.now()).format('YYYY-MM-')}01' AND '${moment(Date.now()).format('YYYY-MM-DD')}'`
          break
        default:
          filter = ''
          break
      }

      // Get user's report
      const reports = await sequelize.query(`SELECT Reports.*, Users.full_name FROM Reports JOIN Users ON Users.id = Reports.user_id ${filter} AND Reports.user_id = ${req.query.userId} ORDER BY Reports.createdAt DESC`, { type: QueryTypes.SELECT })

      // Send response
      return res.status(200).send({
        statusCode: 200,
        status: 'Success',
        message: 'Report found',
        reports
      })
    } catch (error) {
      console.log(error)
      return res.status(500).send({
        statusCode: 500,
        status: 'Failed',
        message: 'Internal server error'
      })
    }
  },

  async allReport (req, res) {
    try {
      // Filter
      let filter = ''
      switch (req.query.filter) {
        case 'today':
          filter = `WHERE DATE(reports.createdAt) = '${moment(Date.now()).format('YYYY-MM-DD')}'`
          break
        case 'week':
          filter = `WHERE DATE(reports.createdAt) BETWEEN '${moment(Date.now()).subtract(7, 'days').format('YYYY-MM-DD')}' AND '${moment(Date.now()).format('YYYY-MM-DD')}'`
          break
        case 'month':
          filter = `WHERE DATE(reports.createdAt) BETWEEN '${moment(Date.now()).format('YYYY-MM-')}01' AND '${moment(Date.now()).format('YYYY-MM-DD')}'`
          break
        default:
          filter = ''
          break
      }

      // Get all report
      const reports = await sequelize.query(`SELECT Reports.*, Users.full_name FROM Reports JOIN Users ON Users.id = Reports.user_id ${filter} ORDER BY Reports.createdAt DESC`, { type: QueryTypes.SELECT })

      // Send response
      return res.status(200).send({
        statusCode: 200,
        status: 'Success',
        message: 'Report found',
        reports
      })
    } catch (error) {
      console.log(error)
      return res.status(500).send({
        statusCode: 500,
        status: 'Failed',
        message: 'Internal server error'
      })
    }
  }
}
