require('dotenv').config()
const path = require('path')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const { User } = require(path.join(__dirname, '../', 'models'))

module.exports = {
  async register (req, res) {
    try {
      // Check if the user already exist
      const user = await User.findOne({ where: { nik: req.body.nik } })

      // If user exist
      if (user) {
        return res.status(400).send({
          statusCode: 400,
          status: 'Failed',
          message: 'User already exist'
        })
      }

      // Else
      // Hash the password
      const salt = await bcrypt.genSalt(10)
      const hashedPassword = await bcrypt.hash(req.body.password, salt)

      // Insert to database
      await User.create({
        role_id: req.body.roleId,
        full_name: req.body.fullName,
        profile_picture: 'default.jpg',
        nik: req.body.nik,
        password: hashedPassword
      })

      // Send response
      return res.status(201).send({
        statusCode: 201,
        status: 'Success',
        message: 'Register success'
      })
    } catch (error) {
      console.log(error)
      return res.status(500).send({
        statusCode: 500,
        status: 'Failed',
        message: 'Internal server error'
      })
    }
  },

  async login (req, res) {
    try {
      // Check if the user exist
      const user = await User.findOne({ where: { nik: req.body.nik } })

      // If user not exist
      if (!user) {
        return res.status(404).send({
          statusCode: 404,
          status: 'Failed',
          message: 'User doesn\'t exist'
        })
      }

      // Else
      // Compare password
      const passwordMatched = await bcrypt.compare(req.body.password, user.password)

      // If the password wrong
      if (!passwordMatched) {
        return res.status(400).send({
          statusCode: 400,
          status: 'Failed',
          message: 'Password wrong'
        })
      }

      // Else
      // Create auth token
      const token = jwt.sign({ userId: user.id, nik: user.nik, userRole: user.role_id }, process.env.SECRET_KEY)

      // Send response
      return res.status(200).send({
        statusCode: 200,
        status: 'Success',
        message: 'Login success',
        token,
        roleId: user.role_id,
        userId: user.id
      })
    } catch (error) {
      console.log(error)
      return res.status(500).send({
        statusCode: 500,
        status: 'Failed',
        message: 'Internal server error'
      })
    }
  },

  async getById (req, res) {
    try {
      // Get the user
      const user = await User.findOne({ where: { id: req.params.id } })

      // If user not exist
      if (!user) {
        return res.status(404).send({
          statusCode: 404,
          status: 'Failed',
          message: 'User doesn\'t exist'
        })
      }

      // Send response
      return res.status(200).send({
        statusCode: 200,
        status: 'Success',
        message: 'User found',
        user
      })
    } catch (error) {
      console.log(error)
      return res.status(500).send({
        statusCode: 500,
        status: 'Failed',
        message: 'Internal server error'
      })
    }
  },

  async updateProfile (req, res) {
    try {
      // Get the user
      const user = await User.findOne({ where: { id: req.params.id } })

      // If user not exist
      if (!user) {
        return res.status(404).send({
          statusCode: 404,
          status: 'Failed',
          message: 'User doesn\'t exist'
        })
      }

      // Check if image uploaded
      let profilePicture = user.profile_picture
      if (req.file) {
        profilePicture = req.file.filename
      }

      // Update profile
      await User.update({ full_name: req.body.fullName || user.full_name, profile_picture: profilePicture }, { where: { id: user.id } })

      // Send response
      return res.status(200).send({
        statusCode: 200,
        status: 'Success',
        message: 'Profile updated'
      })
    } catch (error) {
      console.log(error)
      return res.status(500).send({
        statusCode: 500,
        status: 'Failed',
        message: 'Internal server error'
      })
    }
  },

  async changePassword (req, res) {
    try {
      // Get the user
      const user = await User.findOne({ where: { id: req.params.id } })

      // If user not exist
      if (!user) {
        return res.status(404).send({
          statusCode: 404,
          status: 'Failed',
          message: 'User doesn\'t exist'
        })
      }

      // Check old password
      const passwordMatched = await bcrypt.compare(req.body.oldPassword, user.password)
      if (!passwordMatched) {
        return res.status(400).send({
          statusCode: 400,
          status: 'Failed',
          message: 'Old password wrong'
        })
      }

      // Hash new password
      const salt = await bcrypt.genSalt(10)
      const hashedPassword = await bcrypt.hash(req.body.newPassword, salt)

      // Change password
      await User.update({ password: hashedPassword }, { where: { id: user.id } })

      // Send response
      return res.status(200).send({
        statusCode: 200,
        status: 'Success',
        message: 'Password changed, please login again!'
      })
    } catch (error) {
      console.log(error)
      return res.status(500).send({
        statusCode: 500,
        status: 'Failed',
        message: 'Internal server error'
      })
    }
  }
}
