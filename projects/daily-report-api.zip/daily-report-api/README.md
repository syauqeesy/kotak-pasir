# Daily Report Back End

## About
This repo is for JNE technical test.

## Installation
1. Clone this repository https://github.com/syauqeesy/daily-report-api.
2. Install dependencies with `npm install` command.
3. Copy `env` file to `.env`.
4. Config `.env` file.
5. Create database with `npm run sequelize db:create` command.
6. Migrate tables with `npm run sequelize db:migrate` command.
7. Seed tables with `npm run sequelize db:seed:all` command.
8. Run the application with `npm run dev` for development mode or `npm run start` to start the application.
