require('dotenv').config()
const jwt = require('jsonwebtoken')

module.exports = (request, response, next) => {
  try {
    // Get the bearer token
    const authHeader = request.headers.authorization

    // Check bearer token
    if (!authHeader) {
      return response.status(401).send({
        statusCode: 401,
        status: 'Failed',
        message: 'Access denied'
      })
    }

    // Get the auth token
    const token = authHeader.split(' ')[1]

    // Verify auth token
    const verified = jwt.verify(token, process.env.SECRET_KEY)

    // Add verified token data to the request
    request.user = verified

    // If user eligible
    return next()
  } catch (_) {
    return response.status(500).send({
      statusCode: 500,
      status: 'Failed',
      message: 'Internal server error'
    })
  }
}
