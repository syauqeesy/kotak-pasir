const path = require('path')
const multer = require('multer')

// Create multer storage
const storage = multer.diskStorage({
  // Specify file destination
  destination (request, file, callback) {
    callback(null, path.join(__dirname, '../', 'images'))
  },

  // Specify filename
  filename (request, file, callback) {
    callback(null, Date.now() + file.originalname)
  }
})

// Filter file
const fileFilter = (request, file, callback) => {
  // Check file's mimetype
  if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
    return callback(null, true)
  }

  // If the file not an image
  return request.res.status(400).send({
    statusCode: 400,
    status: 'Failed',
    message: 'Avatar must be an image'
  })
}

module.exports = multer({
  fileFilter,
  storage
})
