module.exports = (request, response, next) => {
  // Check user's role
  if (request.user.userRole !== 1) {
    // If not eligible
    return response.status(401).send({
      statusCode: 401,
      status: 'Failed',
      message: 'Access denied'
    })
  }

  // If user eligible
  return next()
}
