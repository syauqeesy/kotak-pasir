'use strict'

module.exports = {
  up: async (queryInterface, Sequelize) => {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */
    await queryInterface.bulkInsert('Users', [
      { role_id: 1, full_name: 'Ahmad Syauqi', profile_picture: 'default.jpg', nik: '0192817192', password: '$2b$10$Q8Di5aqZ63x6rZNFYJMjzOampjdhSEw11F9WuanCt9b39HX7MEPAm', createdAt: '2021-01-01 00:00:00', updatedAt: '2021-01-01 00:00:00' },
      { role_id: 2, full_name: 'Aziz Rizki', profile_picture: 'default.jpg', nik: '928392382', password: '$2b$10$Q8Di5aqZ63x6rZNFYJMjzOampjdhSEw11F9WuanCt9b39HX7MEPAm', createdAt: '2021-01-01 00:00:00', updatedAt: '2021-01-01 00:00:00' },
      { role_id: 2, full_name: 'Hanif Kumara', profile_picture: 'default.jpg', nik: '239238128', password: '$2b$10$Q8Di5aqZ63x6rZNFYJMjzOampjdhSEw11F9WuanCt9b39HX7MEPAm', createdAt: '2021-01-01 00:00:00', updatedAt: '2021-01-01 00:00:00' }
    ], {})
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Users', null, {})
  }
}
