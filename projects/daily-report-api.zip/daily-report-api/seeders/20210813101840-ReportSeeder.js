'use strict'

module.exports = {
  up: async (queryInterface, Sequelize) => {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */
    await queryInterface.bulkInsert('Reports', [
      { body: 'Melakukan pembersihan di ruang komputer', user_id: 2, createdAt: '2021-08-02 17:00:00', updatedAt: '2021-08-02 17:00:00' },
      { body: 'Memperbaiki beberapa laptop', user_id: 2, createdAt: '2021-08-04 17:00:00', updatedAt: '2021-08-04 17:00:00' },
      { body: 'Membersihkan ruangan kerja', user_id: 2, createdAt: '2021-08-06 17:00:00', updatedAt: '2021-08-06 17:00:00' },
      { body: 'Membersihkan gudang', user_id: 2, createdAt: '2021-08-10 17:00:00', updatedAt: '2021-08-10 17:00:00' },
      { body: 'Memindahkan laptop dari gudang ke kantor', user_id: 2, createdAt: '2021-08-13 17:00:00', updatedAt: '2021-08-13 17:00:00' },

      { body: 'Melakukan penginputan data customer', user_id: 3, createdAt: '2021-08-02 17:00:00', updatedAt: '2021-08-02 17:00:00' },
      { body: 'Merapikan dokumen-dokumen', user_id: 3, createdAt: '2021-08-04 17:00:00', updatedAt: '2021-08-04 17:00:00' },
      { body: 'Menginstal software untuk bekerja', user_id: 3, createdAt: '2021-08-06 17:00:00', updatedAt: '2021-08-06 17:00:00' },
      { body: 'Melakukan perakitan komputer', user_id: 3, createdAt: '2021-08-10 17:00:00', updatedAt: '2021-08-10 17:00:00' },
      { body: 'Menghapus data-data yang sudah tidak dipakai', user_id: 3, createdAt: '2021-08-13 17:00:00', updatedAt: '2021-08-13 17:00:00' },

      { body: 'Melatih para pegawai untuk menggunakan aplikasi', user_id: 1, createdAt: '2021-08-02 17:00:00', updatedAt: '2021-08-02 17:00:00' },
      { body: 'Melakukan absensi rutin', user_id: 1, createdAt: '2021-08-04 17:00:00', updatedAt: '2021-08-04 17:00:00' },
      { body: 'Mengawasi para pegawai yang sedang bekerja', user_id: 1, createdAt: '2021-08-06 17:00:00', updatedAt: '2021-08-06 17:00:00' },
      { body: 'Menginterview calon pekerja baru', user_id: 1, createdAt: '2021-08-10 17:00:00', updatedAt: '2021-08-10 17:00:00' },
      { body: 'Melaporkan hasil kerja para pegawai', user_id: 1, createdAt: '2021-08-13 17:00:00', updatedAt: '2021-08-13 17:00:00' },
    ], {})
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Reports', null, {})
  }
}
