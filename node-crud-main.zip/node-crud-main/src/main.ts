import application from "./application/main";

application().run();
