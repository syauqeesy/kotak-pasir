interface Application {
  run(): void;
}

export default Application;
